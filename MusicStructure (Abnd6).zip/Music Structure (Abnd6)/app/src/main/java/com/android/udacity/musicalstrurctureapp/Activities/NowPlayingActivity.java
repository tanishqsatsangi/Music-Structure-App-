package com.android.udacity.musicalstrurctureapp.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.android.udacity.musicalstrurctureapp.CustomClasses.Songs;
import com.android.udacity.musicalstrurctureapp.R;

public class NowPlayingActivity extends AppCompatActivity {
    TextView songname, songartist;
    SeekBar playbar;
    ImageView songimg;
    ImageButton previoussong, nextsong, playpausebtn, seekforward, seekbackward;
    ImageButton favouriteButton;
    Songs currentsong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_now_playing);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        songname = (TextView) findViewById(R.id.songname);
        songartist = (TextView) findViewById(R.id.artistname);
        playbar = (SeekBar) findViewById(R.id.palyseekbar);
        songimg = (ImageView) findViewById(R.id.songimg);
        previoussong = (ImageButton) findViewById(R.id.previoussong);
        nextsong = (ImageButton) findViewById(R.id.nextsong);
        playpausebtn = (ImageButton) findViewById(R.id.playpausebtn);
        seekbackward = (ImageButton) findViewById(R.id.previoussong);
        seekforward = (ImageButton) findViewById(R.id.seekforward);
        favouriteButton = (ImageButton) findViewById(R.id.likebutton);

        Intent i = getIntent();

        String song_name = i.getStringExtra("Songname");
        String artist_name = i.getStringExtra("Artistname");
        String song_duraton = i.getStringExtra("Duration");
        int song_imgresid = i.getIntExtra("imgid", R.drawable.ic_launcher_foreground);
        currentsong = new Songs(song_name, artist_name, song_duraton, song_imgresid);
        songname.setText(song_name);
        songartist.setText(artist_name);
        songimg.setImageResource(song_imgresid);
        favouriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FavouriteActivity fa_obj = new FavouriteActivity();
                fa_obj.addsongtofavourites(currentsong);
            }
        });
    }
}
