package com.android.udacity.musicalstrurctureapp.Activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.TextView;

import com.android.udacity.musicalstrurctureapp.Adapters.FavouriteListAdapter;
import com.android.udacity.musicalstrurctureapp.CustomClasses.Songs;
import com.android.udacity.musicalstrurctureapp.R;

import java.util.ArrayList;

public class FavouriteActivity extends AppCompatActivity {
    ListView favouritesonglist;
    ArrayList<Songs> favouritesongs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        TextView favoritetextview = (TextView) findViewById(R.id.favoriteempty);
        favouritesonglist = (ListView) findViewById(R.id.favourite_activity_listview);
        if (favouritesongs.isEmpty()) {
            favoritetextview.setText("No Favourite SOng Available");
        } else {
            FavouriteListAdapter adapter = new FavouriteListAdapter(this, favouritesongs);
            favouritesonglist.setAdapter(adapter);
        }


    }

    public void addsongtofavourites(Songs song) {
        favouritesongs.add(new Songs(song.getSong_name(), song.getArtist_name(), song.getDuration(), song.getImg_res_id()));
    }
}
