package com.android.udacity.musicalstrurctureapp.Activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.android.udacity.musicalstrurctureapp.Adapters.LibraryListAdapter;
import com.android.udacity.musicalstrurctureapp.CustomClasses.Songs;
import com.android.udacity.musicalstrurctureapp.R;

import java.util.ArrayList;

public class LibraryActivity extends AppCompatActivity {
    ListView songslistview;
    ArrayList<Songs> librarysongs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_library);
        songslistview = (ListView) findViewById(R.id.Library_activity_listview);

        librarysongs.add(new Songs("name", "artist", "0:00", R.drawable.music));
        librarysongs.add(new Songs("name", "artist", "0:00", R.drawable.music));
        librarysongs.add(new Songs("name", "artist", "0:00", R.drawable.music));
        librarysongs.add(new Songs("name", "artist", "0:00", R.drawable.music));
        librarysongs.add(new Songs("name", "artist", "0:00", R.drawable.music));

        LibraryListAdapter adapter = new LibraryListAdapter(this, librarysongs);
        songslistview.setAdapter(adapter);

    }

    public ArrayList<Songs> songList() {
        librarysongs.add(new Songs("name", "artist", "0:00", R.drawable.ic_launcher_foreground));

        return librarysongs;
    }
}
