package com.android.udacity.musicalstrurctureapp.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.udacity.musicalstrurctureapp.CustomClasses.Songs;
import com.android.udacity.musicalstrurctureapp.R;

import java.util.ArrayList;

public class RecentListAdapter extends ArrayAdapter<Songs> {

    public RecentListAdapter(Context context, ArrayList<Songs> songs) {
        super(context, 0, songs);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View itemView = convertView;
        if (itemView == null) {
            itemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.songsdisplay_layout, parent, false);
        }
        Songs currentsong = getItem(position);
        ImageView songimgview = (ImageView) itemView.findViewById(R.id.song_img);
        TextView songname = (TextView) itemView.findViewById(R.id.song_name);
        TextView artistname = (TextView) itemView.findViewById(R.id.artist_name);
        TextView songduration = (TextView) itemView.findViewById(R.id.song_duration);

        songimgview.setImageResource(currentsong.getImg_res_id());
        songname.setText(currentsong.getSong_name());
        artistname.setText(currentsong.getArtist_name());
        songduration.setText(currentsong.getDuration());
        return itemView;

    }
}
