package com.android.udacity.musicalstrurctureapp.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.android.udacity.musicalstrurctureapp.CustomClasses.Songs;
import com.android.udacity.musicalstrurctureapp.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button recentbtn, favouritebtn, librarybtn, nowplayingbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recentbtn = (Button) findViewById(R.id.recentsongs);
        favouritebtn = (Button) findViewById(R.id.favouritesongs);
        librarybtn = (Button) findViewById(R.id.librarysongs);
        nowplayingbtn = (Button) findViewById(R.id.nowplayingsong);
        recentbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RecentActivity.class));
            }
        });
        favouritebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, FavouriteActivity.class));
            }
        });
        librarybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, LibraryActivity.class));
            }

        });

        nowplayingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NowPlayingActivity.class);
                LibraryActivity l = new LibraryActivity();
                ArrayList<Songs> list = l.songList();
                Songs firstsong = list.get(0);
                intent.putExtra("Songname", firstsong.getSong_name());
                intent.putExtra("Artistname", firstsong.getArtist_name());
                intent.putExtra("Duration", firstsong.getDuration());
                intent.putExtra("imgid", firstsong.getImg_res_id());
                startActivity(intent);

            }
        });
    }
}
