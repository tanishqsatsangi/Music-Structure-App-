package com.android.udacity.musicalstrurctureapp.Activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.TextView;

import com.android.udacity.musicalstrurctureapp.Adapters.RecentListAdapter;
import com.android.udacity.musicalstrurctureapp.CustomClasses.Songs;
import com.android.udacity.musicalstrurctureapp.R;

import java.util.ArrayList;

public class RecentActivity extends AppCompatActivity {
    ListView recentsongslistview;
    ArrayList<Songs> recentsongs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        recentsongslistview = (ListView) findViewById(R.id.recent_activity_listview);
        TextView recentisempty = (TextView) findViewById(R.id.recentisempty);
        if (recentsongs.isEmpty()) {
            recentisempty.setText("No recently song Available");
        } else {
            RecentListAdapter adapter = new RecentListAdapter(this, recentsongs);
            recentsongslistview.setAdapter(adapter);

        }

    }

    public void addrecentSong(Songs s) {
        recentsongs.add(new Songs(s.getSong_name(), s.getArtist_name(), s.getDuration(), s.getImg_res_id()));
    }
}
