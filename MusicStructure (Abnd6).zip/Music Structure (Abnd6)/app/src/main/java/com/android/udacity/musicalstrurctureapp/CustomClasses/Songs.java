package com.android.udacity.musicalstrurctureapp.CustomClasses;

public class Songs {
    String song_name;
    String artist_name;
    String duration;
    int img_res_id;

    public Songs() {

    }

    public Songs(String songname, String artistname, String songduration, int imgid) {
        song_name = songname;
        artist_name = artistname;
        duration = songduration;
        img_res_id = imgid;
    }

    public String getSong_name() {
        return song_name;
    }

    public String getArtist_name() {
        return artist_name;
    }

    public String getDuration() {
        return duration;
    }

    public int getImg_res_id() {
        return img_res_id;
    }
}
